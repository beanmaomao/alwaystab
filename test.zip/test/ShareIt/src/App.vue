<template>
  <div class="app">
    <h2 class="title">ONLINE-SHARE-NOTEBOOK</h2>
    <!-- 导航区 -->
    <div class="navigate">
      <RouterLink to="/show" active-class="xiaozhupeiqi">展示</RouterLink>
      <RouterLink to="/write" active-class="xiaozhupeiqi" id="write">编写与更新</RouterLink>
    </div>
    <!-- 展示区 -->
    <div class="main-content">
      <RouterView></RouterView>
    </div>
  </div>
</template>

<script lang="ts" setup name="App">
  import {RouterView,RouterLink} from 'vue-router'
</script>

<style>
    /* App */
  .title {
    text-align: center;
    word-spacing: 5px;
    margin: 30px 0;
    height: 70px;
    line-height: 70px;
    background-image: linear-gradient(45deg, gray, white);
    border-radius: 10px;
    box-shadow: 0 0 2px;
    font-size: 30px;
  }
  .navigate {
    display: flex;
    justify-content: space-around;
    margin: 0 100px;
  }
  .navigate a {
    display: block;
    text-align: center;
    width: 90px;
    height: 40px;
    line-height: 40px;
    border-radius: 10px;
    background-color: gray;
    text-decoration: none;
    color: white;
    font-size: 18px;
    letter-spacing: 5px;
  }
  #write{
    width: 200px;
  }
  .navigate a.xiaozhupeiqi {
    background-color: crimson;
    color: cornsilk;
    font-weight: 900;
    text-shadow: 0 0 1px black;
    font-family: 微软雅黑;
  }
  .main-content {
    margin: 0 auto;
    margin-top: 30px;
    border-radius: 10px;
    width: 100vw;
    height: 80vh;
    border: 1px solid;
  }
</style>
